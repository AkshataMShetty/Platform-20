using System;

namespace PersonLib
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

