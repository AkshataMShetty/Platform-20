using System;

namespace Assignment2_Q2
{
	public class ShapeUI
	{
		public ShapeUI ()
		{
		}
	}
}

