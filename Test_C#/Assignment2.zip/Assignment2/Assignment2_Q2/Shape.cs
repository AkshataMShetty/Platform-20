using System;

namespace Assignment2_Q2
{
	interface Shape{
		void CalculateArea ();
	}

}

