using System;

namespace Assignment1_Mileage
{
	class Program
	{
		public static void Main ()
		{
			Mileage mil = new Mileage ();
			mil.ReadInput ();
			mil.Display ();
		}
	}
}
