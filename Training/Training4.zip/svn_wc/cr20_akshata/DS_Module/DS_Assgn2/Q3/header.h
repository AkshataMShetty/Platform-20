#include <stdio.h>
#include <stdlib.h>

//#define QUEUE_SIZE 256
#define QUEUE_SIZE 10

#define INT_BIT (sizeof (int) * 8)
//my_fgets.c
void my_fgets (int *);

//my_atoi.c
int my_atoi (char *);

//operations on queue
//int dlete (int *, int *, int *);
//void insert (int *, int *, int);
