#include "header.h"
void printArray(int arr[], int n)
{
    int i;
    for (i = 0; i < n; i++)
        printf("%d\t",arr[i]);
}
 

