#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void swap ( int* a, int* b );
int minIndex(int a[], int i, int j);
void recurSelectionSort(int a[], int n, int index);
void printArray(int arr[], int n);
