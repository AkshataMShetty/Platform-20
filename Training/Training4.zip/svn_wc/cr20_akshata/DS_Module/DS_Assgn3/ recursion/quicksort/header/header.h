#include <stdio.h>
#include<stdlib.h>
#define MAX 256


void swap(int* a, int* b);
int partition (int arr[], int low, int high);
void quickSort(int arr[], int low, int high);
void printArray(int arr[], int size);

