#include <stdio.h>
#include <stdlib.h>
#define MAX 256
void bubbleSort(int arr[], int n);
void printArray(int arr[], int n);
void swap ( int* a, int* b );
