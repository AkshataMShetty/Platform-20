#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void merge(int arr[], int l, int m, int r);
void mergeSort(int arr[], int l, int r);
void printArray(int A[], int size);

