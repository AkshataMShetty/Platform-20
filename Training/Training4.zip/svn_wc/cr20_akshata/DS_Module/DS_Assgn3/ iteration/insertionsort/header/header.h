#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void printArray(int arr[], int n);
void insertionSort(int a[],int n);
