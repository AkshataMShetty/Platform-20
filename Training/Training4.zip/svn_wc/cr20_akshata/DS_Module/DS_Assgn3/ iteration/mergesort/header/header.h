#include<stdlib.h>
#include<stdio.h>
#define MAX 256 

void printArray(int *A, int size);
void merge(int arr[], int l, int m, int r);
void mergeSort(int arr[], int n);
int min(int x, int y);

