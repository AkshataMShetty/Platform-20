#include "header.h"

int min(int x, int y) { return (x<y)? x :y; }

