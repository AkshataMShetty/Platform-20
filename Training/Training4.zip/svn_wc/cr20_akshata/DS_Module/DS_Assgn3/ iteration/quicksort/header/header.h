#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void quickSortIterative (int arr[], int l, int h);

void swap ( int* a, int* b );

int partition (int arr[], int l, int h);

void printArr( int arr[], int n );

