#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void swap(int *xp, int *yp);
void bubbleSort(int arr[], int n);
void printArray(int arr[], int size);

