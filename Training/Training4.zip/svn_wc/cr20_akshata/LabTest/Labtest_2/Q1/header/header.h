#include<stdio.h>
#include<stdlib.h>


#define MAX 256

int freq_of_occurance(const char* ,const char*);
char *readinput(char*);
