#include"header.h"

char *my_index(const char *str , int c)
{
	
	while(*str != '\0')
	{
		if(*str == c)
		{
			break;
		}
		else
		{
		
			str++;
		}
			
	}

	printf("%s",str);
	return str;
}

			
