#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define MAX 255

struct node{
	int data;
	struct node *left ;
	struct node *right;
};


struct node* insert_node (struct node*,int);
struct node* delete_node(struct node*,int);
void display(struct node*);
