#include "header.h"

void display(struct node *r)
{
	if(r == NULL){
	//	printf("empty list\n");
		return;
	}
	printf("%d\n",r -> data);
	display(r -> left);
	display(r -> right);
}
