/* Multiplication of 9 */
#include "header.h"
int multiply( int num)
{
	return (num << 3) + num;
	
}
	
