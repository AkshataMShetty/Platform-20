#include<stdio.h>
#include<stdlib.h>

#define MAX 256

int my_atoi(char *);
int little_to_big_endian(unsigned int);
int getbits(int,int,int);
