/* To get n bits right adjusted */
unsigned int getbits(unsigned int num, int pos, int no_of_bit)
{
	return (num >> (pos+1-no_of_bit)) & ~(~0 << no_of_bit);
}
