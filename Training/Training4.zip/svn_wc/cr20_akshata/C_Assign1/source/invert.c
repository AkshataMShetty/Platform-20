/* To invert n bits from postion p in a given number */

#include"header.h"

int invert(unsigned int num,int pos,int no_of_bits)
{
	return num ^ (getbits(num,pos,no_of_bits ) << (pos + 1 - no_of_bits));
}
