my_string = 'My String'

print my_string

print my_string +' ' + my_string

print (my_string + ' ') * 3
