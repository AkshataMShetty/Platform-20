def lexicograph(string):
	x = []
	x = sorted(string)
	return x

y = raw_input("enter a string:")
result = lexicograph(y)
print result










