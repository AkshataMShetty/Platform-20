string1 = "Global"
string2 = "Edge"

string3 = string1 +' '+ string2
print string3

print string3.find("Edge")

length = len(string3)
print "length of string3"
print length

print string3.split()

print string3.replace('a','e')

string4 = "     messy string    "
print string4.strip()

print string4.rstrip()

print string4.lstrip()

print string1.upper()

print string1.lower()


