string = 'string'

if(string.isupper())==(not(string.islower())) :
	print "same"
else : 
	print "not same"

