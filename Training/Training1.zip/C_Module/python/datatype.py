
a = 1000000000000
a = 10.2365
a = "divya"
print a
