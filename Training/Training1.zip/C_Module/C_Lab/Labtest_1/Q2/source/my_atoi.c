/* convert char to integer */

int my_atoi(char *s)
{
	int index ;
	int num = 0;

	for(index = 0 ; (s[index] <= '9') & (s[index] >= '0') ; index++){
		num = num * 10 + ( s[index] - '0') ;
		
	}
	return num;
}
