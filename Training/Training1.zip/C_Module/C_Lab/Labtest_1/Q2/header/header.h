#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int my_atoi(char *);

int multiply(int);
