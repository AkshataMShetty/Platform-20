#include"header.h"

char *readinput(char *input)
{
	if(NULL == fgets(input,MAX,stdin))
	{
		perror("fgest failure \n");
		exit(EXIT_FAILURE);
	}
	return input;
}
