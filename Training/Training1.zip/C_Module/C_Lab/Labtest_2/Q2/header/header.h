#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

#define MAX 256

char *readinput(char*);
char *my_index(const char* , int );
