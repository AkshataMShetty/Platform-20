/* To validate the input */
int validate(char *str)
{
	if((*str == '0') || (*str == '1'))
		return 1;
	else
		return 0;
}
