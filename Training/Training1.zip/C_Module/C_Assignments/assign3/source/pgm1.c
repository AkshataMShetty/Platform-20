#include<stdio.h>
int main(int argc , char *argv[])
{
	printf("number of files is %d",(argc - 1));
	return 0;
}
