#include<header.h>
int sum(int a, int b)
{
    return a+b;
}

int diff(int a,int b)
{
    return a-b;
}

int mul(int a,int b)
{
    return a*b;
}

int div(int a, int b)
{
    return a/b;
}

