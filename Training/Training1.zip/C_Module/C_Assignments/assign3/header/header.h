#include<stdio.h>
#define MAX 256


int my_atoi(char *);
int sum(int , int );
int diff(int ,int );
int mul(int ,int );
int div(int , int );

