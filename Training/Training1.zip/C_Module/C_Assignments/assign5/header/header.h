#include<stdio.h>
#include<stdlib.h>

FILE *fp;
FILE *fp2;

void check_comment(char);
void block_comment();
void single_comment();


