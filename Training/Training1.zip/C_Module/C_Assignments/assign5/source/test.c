/* To add two numbers 
	program */

#include <stdio.h>
int main()   // main function
{
	int a = 10;
	int b = 20;

	printf("sum = %d\n /* fsffs */", a+b);
	return 0;
	
}
