//int a ;
//volatile extern  int a;
const int a = 10;		
int main(void)
{
//	a = 6;
//	int *ptr = &a;
 const int a = 1;		
//	*ptr = 88;
	printf("%d\n",a);
	return 0;
}
