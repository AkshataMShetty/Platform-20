struct node{
	int item;
	struct node *next;
};


struct node1{
	int value;
	struct node *next;
	struct node *prev;
};
