#include <stdio.h>

int main()
{
	long a;
	printf("%d\n",sizeof(long));

	return 0;
}
