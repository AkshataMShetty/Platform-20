#include <stdio.h>
int main(void)
{
	char arr[4] = "Hello World";
	printf("%s\n",arr);
	return 0;
}
