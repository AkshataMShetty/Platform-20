#include<stdio.h>
int a;
int main(void)
{

	printf("in main\n");
	printf("%p\n",&a);
	printf("%d\n",a);
	return 0;
}
