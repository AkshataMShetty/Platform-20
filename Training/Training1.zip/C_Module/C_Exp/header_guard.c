#include "header_guard.h"
#include "header_guard.h"
#include "header_guard.h"
#include "header_guard.h"
#include "header_guard.h"
#include "header_guard.h"
int main()
{
	int index;
	int sum;
	sum = index + 10;
	printf("%d\n",sum);

	return 0;
}
