#include<stdio.h>

//int register a;
//register int p;
a = 2;
int register a;

int main(void)
{
	a = 5;
	printf("%d\n", a);

	return 0;

}
