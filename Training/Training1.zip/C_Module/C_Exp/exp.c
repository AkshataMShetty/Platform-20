#include <stdio.h>
int main(void)
{
	double d;
	printf("%d\n",sizeof(d));
	return 0;
}
