#include<stdio.h>
int main()
{
	unsigned int a = -3;
	int b = 3;
	if(a < b)
		printf("a is less than b\n");
	else
		Printf("a is greater then b\n");

	if(1 < -1)
		printf("1 is less than -1\n");
	else
		printf("-1 is less than 1\n");

	return 0;
}
