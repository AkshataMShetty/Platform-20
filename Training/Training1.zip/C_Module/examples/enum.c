#include<stdio.h>
enum e{a,b} ins;


int main(void)
{
	return 0;
}
