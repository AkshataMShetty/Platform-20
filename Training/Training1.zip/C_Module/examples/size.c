#include <stdio.h>
main()
{
	int num = sizeof(main());
	printf("%d\n",num);
	return 0;
}

