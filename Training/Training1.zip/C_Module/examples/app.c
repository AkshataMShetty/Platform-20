#include<stdio.h>
#include<stdlib.h>
_start()
{
	printf("without main\n");
	exit(0);
}
