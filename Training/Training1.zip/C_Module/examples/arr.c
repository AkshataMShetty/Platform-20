#include<stdio.h>
int main()
{
	int a[10],i;
	for(i=0;i<50;i++)
	{
		a[i] = i+1;
		printf("%d",a[i]);
	}
	return 0;
}
