#include <stdio.h>
#include <stdlib.h>
#define MAX 256

void swap(int *xp, int *yp);
void selectionSort(int arr[], int n);
void printArray(int arr[], int size);
