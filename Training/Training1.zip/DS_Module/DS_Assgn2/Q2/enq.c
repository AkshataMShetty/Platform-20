#include "header.h"

void enq (node **rear, node *new)
{
	if (*rear) {
		(*rear) -> next = new;
	}
	*rear = new;
}
