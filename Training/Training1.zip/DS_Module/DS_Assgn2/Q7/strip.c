#include "header.h"

void strip (char * s)
{
	//int len = my_strlen (s);
	int i = 0;

	while ((s != NULL) && (s[i] != '\0')) {
		if (s[i] == '\n') {
			s[i] = '\0';
			break;
		} else {
			i++;
		}
	}
}
