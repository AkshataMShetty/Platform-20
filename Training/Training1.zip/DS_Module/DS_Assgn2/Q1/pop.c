#include "header.h"

int pop (int *stack, int *top)
{
	if (*top == -1) {
		printf ("Stack empty\n");
		exit (EXIT_FAILURE);
	} else {
		return (stack[(*top)--]);
	}
}
