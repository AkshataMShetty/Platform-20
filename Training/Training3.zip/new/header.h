#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUF_SIZE 256

int validate(char *);
int isalphanum(char *);
int isdigit(char *);
