#include "header.h"

int isalphanum(char *tok)
{
	int index = 0;
	while(*(tok + index) != '\0')
	{
		
	}
}
